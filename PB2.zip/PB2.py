import pandas as pd
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.functions import json_tuple,col,get_json_object
spark = SparkSession.builder.appName('PB2').getOrCreate()

pb2 = pd.read_excel('/home/ajay/Downloads/PB2.xlsx',keep_default_na=False)

pb2 = pb2.astype(str)

pb2 = spark.createDataFrame(pb2)
# df = pb2.select('loan_app_id',get_json_object(col('response_json'),'$.bureau_respornse').alias('bureau_reaponse'))

df = pb2.select('loan_app_id',json_tuple(col('response_json'),'bureau_response','partner','report')).toDF('loan_app_id','bureau_response','partner','report')
df = df.select('*',json_tuple(col('bureau_response'),'calculated_variables','decision')).toDF('loan_app_id','bureau_response','partner','report','calculated_variable','decision')
df1 = df.select('*',json_tuple(col('calculated_variable'),'bureau_name','bureau_score','final_tenure','final_roi','cust_bureau_vintage','final_tradeline_vintage','final_tradeline_name','monthly_income','max_credit_card_limit',
                               'total_pl_current_bal','max_ever_pl_amount','pl_score_v2','total_pl_util','max_ever_hl_amount','segment2','total_pl_sanctioned_amt',
                               'current_obligation','unsec_emi_wt_cc','nbr_live_pl','nbr_actv_act_opened_in_3m','nbr_actv_act_opened_in_6m','nbr_actv_act_opened_in_12m',
                               'comp_cat1','comp_sector','prime_model_decile','comp_industry','top3_cc_limit_sum','top3_cc_os_sum','mobile_number')).toDF('loan_app_id','bureau_response','partner','report','calculated_variable','decision',
                                                                                                                                          'bureau_name',
                                                                                                                                          'bureau_score',
                                                                                                                                          'final_tenure',
                                                                                                                                          'final_roi',
                                                                                                                                          'cust_bureau_vintage',
                                                                                                                                          'final_tradeline_vintage',
                                                                                                                                          'final_tradeline_name',
                                                                                                                                          'monthly_income',
                                                                                                                                          'max_credit_card_limit',
                                                                                                                                          'total_pl_current_bal',
                                                                                                                                          'max_ever_pl_amount',
                                                                                                                                          'pl_score_v2',
                                                                                                                                          'total_pl_util',
                                                                                                                                          'max_ever_hl_amount',
                                                                                                                                          'segment2',
                                                                                                                                          'total_pl_sanctioned_amt',
                                                                                                                                          'current_obligation',
                                                                                                                                          'unsec_emi_wt_cc',
                                                                                                                                          'nbr_live_pl',
                                                                                                                                          'nbr_actv_act_opened_in_3m',
                                                                                                                                          'nbr_actv_act_opened_in_6m',
                                                                                                                                          'nbr_actv_act_opened_in_12m',
                                                                                                                                          'comp_cat1',
                                                                                                                                          'comp_sector',
                                                                                                                                          'prime_model_decile',
                                                                                                                                          'comp_industry',
                                                                                                                                          'top3_cc_limit_sum',
                                                                                                                                          'top3_cc_os_sum','mobile_number'
                                                                                                                                          )
df1.show(100)