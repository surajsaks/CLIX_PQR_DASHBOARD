
from pyspark.sql import SparkSession, SQLContext
from pyspark import SparkConf, SparkContext
from pyspark.sql.types import *
from pyspark.sql.functions import col,split,to_date
import config

id = config.access_id
key = config.access_key

spark = SparkSession.builder.appName('HL_MIS')\
		.config('spark.hadoop.fs.s3a.aws.credentials.provider','org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider')\
		.getOrCreate()

spark.sparkContext._jsc.hadoopConfiguration().set("fs.s3a.access.key", id)
spark.sparkContext._jsc.hadoopConfiguration().set("fs.s3a.secret.key", key)
spark.sparkContext._jsc.hadoopConfiguration().set("fs.s3a.endpoint", "s3.amazonaws.com")

col_list = ['LAN','entitydesc','branchdesc','Max_auditdate','dealername','lovdescaccountsofficer','rofficerdesc','referraliddesc','employeenamedesc',
		'custshrtname','fintypedesc','custsegment','custsubsegment','lovdescfinancingamount','recordstatus','actualamount']

audit_df = spark.read.parquet("s3a://clix-lumiq-edl/indexed/platinum/pennant/plfaudit/adtfinancemain.parquet")
rmt_df = spark.read.parquet("s3a://clix-lumiq-edl/indexed/platinum/pennant/plf/rmtfinancetypes.parquet")
amt_df = spark.read.parquet("s3a://clix-lumiq-edl/indexed/platinum/pennant/plf/amtvehicledealer.parquet")
off_df = spark.read.parquet("s3a://clix-lumiq-edl/indexed/platinum/pennant/plf/relationshipofficers.parquet")
smt_df = spark.read.parquet("s3a://clix-lumiq-edl/indexed/platinum/pennant/plf/smtdivisiondetail.parquet")
ent_df = spark.read.parquet("s3a://clix-lumiq-edl/indexed/platinum/pennant/plf/entity.parquet")
fin_df = spark.read.parquet("s3a://clix-lumiq-edl/indexed/platinum/pennant/plf/finpftdetails.parquet")
branch_df = spark.read.parquet("s3a://clix-lumiq-edl/indexed/platinum/pennant/plf/rmtbranches.parquet")
cust_df = spark.read.parquet("s3a://clix-lumiq-edl/indexed/platinum/pennant/plf/customers.parquet")
fee_df = spark.read.parquet("s3a://clix-lumiq-edl/indexed/platinum/pennant/plf/finfeedetail.parquet")
fm_df = spark.read.parquet("s3a://clix-lumiq-edl/indexed/platinum/pennant/plf/financemain_view.parquet")

#fm_df.createOrReplaceTempView("fm")

a_df = audit_df.filter(~(audit_df.op == 'D'))
a_df = a_df.groupBy('finreference').agg({'auditdate':'max','DSACODE':'max','referralid':'max'})\
		.withColumnRenamed('finreference','LAN').withColumnRenamed('max(auditdate)','Max_auditdate')\
		.withColumnRenamed('max(DSACODE)','Max_DSACODE').withColumnRenamed('max(referralid)','max_referralid')

t_df = audit_df.filter(audit_df.fincategory.isin({"HLMORTG", "K12"}))

fee_df = fee_df.filter((fee_df.finevent=='ADDDBSP')&(fee_df.feetypeid=='69'))
fee_df = fee_df.withColumn('p_dt', split(fee_df.postdate, ' ').getItem(0))
fee_df = fee_df.withColumn('p_dt', to_date(fee_df.p_dt))
fee_df = fee_df.filter(fee_df.p_dt>='2022-04-01').drop('p_dt')
fee_df = fee_df.select('finreference','feetypeid','actualamount')

a_t_cond = [a_df.LAN==t_df.finreference,a_df.Max_auditdate==t_df.auditdate]
a_df = a_df.join(t_df,a_t_cond,'left')

rmt_df = rmt_df.withColumnRenamed('fintype','fintype_drop').drop('nextrolecode','recordstatus')
a_rmt_cond = [a_df.fintype==rmt_df.fintype_drop]
a_df = a_df.join(rmt_df,a_rmt_cond,'left').drop('fintype_drop')

amt_df = amt_df.drop('nextrolecode','recordstatus')
a_amt_cond = [a_df.Max_DSACODE==amt_df.dealerid]
a_df = a_df.join(amt_df,a_amt_cond,'left')

off_df = off_df.drop('nextrolecode','recordstatus')
a_off_cond = [a_df.max_referralid==off_df.rofficercode]
a_df = a_df.join(off_df,a_off_cond,'left')

smt_df = smt_df.drop('nextrolecode','recordstatus')
a_smt_cond = [a_df.findivision==smt_df.divisioncode]
a_df = a_df.join(smt_df,a_smt_cond,'left')

ent_df = ent_df.withColumnRenamed('entitycode','entitycode_drop').drop('nextrolecode','recordstatus')
a_et_cond = [a_df.entitycode==ent_df.entitycode_drop]
a_df = a_df.join(ent_df,a_et_cond,'left')

fin_df = fin_df.withColumnRenamed('finreference','finreference_drop').drop('finbranch','custid')
a_fin_cond = [a_df.finreference==fin_df.finreference_drop]
a_df = a_df.join(fin_df,a_fin_cond,'left').drop('finreference_drop')

branch_df = branch_df.drop('nextrolecode','recordstatus')
a_branch_cond = [a_df.finbranch==branch_df.branchcode]
a_df = a_df.join(branch_df,a_branch_cond,'left')

cust_df = cust_df.withColumnRenamed('custid','custid_drop').drop('nextrolecode','recordstatus')
a_cust_cond = [a_df.custid==cust_df.custid_drop]
a_df = a_df.join(cust_df,a_cust_cond,'left').drop('custid')

fee_df = fee_df.withColumnRenamed('finreference','finreference_drop').drop('nextrolecode','recordstatus')
a_fee_cond = [a_df.finreference==fee_df.finreference_drop]
a_df = a_df.join(fee_df,a_fee_cond,'left').drop('finreference_drop')

fm_df = fm_df.withColumnRenamed('finreference','finreference_drop').drop('nextrolecode','recordstatus')
a_fm_cond = [a_df.finreference==fm_df.finreference_drop]
a_df = a_df.join(fm_df,a_fm_cond,'left').drop('finreference_drop')

a_df = a_df.where(col('nextrolecode').like("%PSV%"))
a_df = a_df.withColumn('p_dt', split(a_df.auditdate, ' ').getItem(0))
a_df = a_df.withColumn('p_dt', to_date(a_df.p_dt))
a_df = a_df.filter(a_df.p_dt>='2022-04-01').drop('p_dt')

a_df = a_df.select(*col_list)
a_pd = a_df.toPandas()
a_pd.to_csv('/home/2022018/sanction.csv')
